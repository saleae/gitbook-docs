/**
 * I2C example for mbed
 * 
 * Reads temperature from TMP102 and prints it to the serial terminal.
 * 
 * To run: upload .bin file to your Nucleo-F446RE
 * To use in a project: create a new mbed project (os.mbed.com) with the 
 * Nucleo-F446RE as the target. Copy and paste this code into main.cpp.
 * 
 * Copyright (c) 2018 Saleae, Inc.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#include "mbed.h"

// Parameters
const int TMP102_ADDR = 0x48 << 1;  // Use 8-bit address
const int REG_TEMP = 0x00;

// Serial object, set baud rate to 115200
Serial serial(SERIAL_TX, SERIAL_RX, 115200);

// I2C object
I2C i2c(PB_9, PB_8);

int main() {
    
    char buf[2];
    int16_t val;
    float temp_c;
    
    while(1) {
    
        // Tell the TMP102 that we want to read from the temperature register
        i2c.write(TMP102_ADDR, REG_TEMP, 1);
        
        // Read 2 bytes from the temperature register
        i2c.read(TMP102_ADDR, buf, 2);
        
        // Combine the bytes
        val = ((int16_t)buf[0] << 4) | (buf[1] >> 4);
        
        // Convert to 2's complement, since temperature can be negative
        if ( val > 0x7FF ) {
            val |= 0xF000;
        }
        
        // Convert to float temperature value (Celsius)
        temp_c = val * 0.0625;
        
        // Print to serial terminal
        serial.printf("%.2f C\r\n", temp_c);
        
        wait(0.2);
    }
}