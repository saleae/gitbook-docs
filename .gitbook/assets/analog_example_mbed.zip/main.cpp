/**
 * Analog Example for mbed
 * 
 * Produces a sinewave on pin PA_4 of the Nucleo-F446RE.
 * 
 * To run: upload .bin file to your Nucleo-F446RE
 * To use in a project: create a new mbed project (os.mbed.com) with the 
 * Nucleo-F446RE as the target. Copy and paste this code into main.cpp.
 * 
 * Copyright (c) 2018 Saleae, Inc.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#include "mbed.h"

#ifndef M_PI
#define M_PI    3.141592653589793238462
#endif

// Pins
AnalogOut dac_out1(PA_4);

// Parameters
const int BUF_SIZE = 360;       // Each degree
const float AMPLITUDE = 0.5;    // Normalized to max GPIO voltage
const float OFFSET = 0.5;       // Normalized to max GPIO voltage
const float FREQUENCY = 100.0;  // Hz (not exact due to overhead DAC instructions)

// Calculate delay between DAC updates
const uint16_t DELAY_US = (uint16_t)(((1 / FREQUENCY) / BUF_SIZE) * 1000000);

// Function definitions
void calc_sinewave(float * sinewave, int len);

int main() {
    
    float sine_buf[BUF_SIZE];

    // Pre-calculate sinewave and store to lookup table
    calc_sinewave(sine_buf, BUF_SIZE);
    
    // Loop forever
    while(1) {      

        // Write sinewave to DAC at each degree
        for (int i = 0; i < BUF_SIZE; i++) {
            dac_out1 = sine_buf[i];
            wait_us(DELAY_US);
        }
    }
}

// Calculate sinewave
void calc_sinewave(float * sinewave, int len) {
    for ( int i = 0; i < len; i++ ) {
        double rad = (M_PI * i) / 180.0;
        sinewave[i] = (AMPLITUDE * cos(rad)) + OFFSET;
    }
}
