Windows:
SaleaeDevice.dll
SaleaeDevice.lib

Mac:
libSaleaeDevice.dylib

Linux:
libSaleaeDevice.so

Linux 64-bit:
libSaleaeDevice64.so

Note: If you're on 64-bit Linix, remove libSaleaeDevice.so, and then rename libSaleaeDevice64.so to libSaleaeDevice.so

