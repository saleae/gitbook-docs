/**
 * UART Example for mbed
 * 
 * Echos any character received over the serial line back out.
 * 
 * To run: upload .bin file to your Nucleo-F446RE
 * To use in a project: create a new mbed project (os.mbed.com) with the 
 * Nucleo-F446RE as the target. Copy and paste this code into main.cpp.
 * 
 * Copyright (c) 2018 Saleae, Inc.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#include "mbed.h"

// Serial object, set baud rate to 115200
Serial serial(SERIAL_TX, SERIAL_RX, 115200);

int main() {
    
    char c;
    
    // If we see a character, echo it back
    while(1) {
        if ( serial.readable() ) {
            c = serial.getc();
            serial.putc(c);
        }
    }
}
