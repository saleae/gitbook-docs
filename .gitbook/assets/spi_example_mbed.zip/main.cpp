/**
 * SPI example for mbed
 * 
 * Reads analog voltage from MCP3002 and prints it to the serial terminal.
 * 
 * To run: upload .bin file to your Nucleo-F446RE
 * To use in a project: create a new mbed project (os.mbed.com) with the 
 * Nucleo-F446RE as the target. Copy and paste this code into main.cpp.
 * 
 * Copyright (c) 2018 Saleae, Inc.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#include "mbed.h"

// Parameters
const int ADC_CHANNEL = 0;  // Which channel to use on the MCP3002
const float VREF = 3.3;     // Voltage applied to VREF pin on the MCP3002
const int MAX_ADC = 1024;   // Max value of ADC (plus 1)

// Serial object, set baud rate to 115200
Serial serial(SERIAL_TX, SERIAL_RX, 115200);

// SPI object
SPI spi(PA_7, PA_6, PA_5);   // MOSI, MISO, SCLK

// CS pin object
DigitalOut cs(PB_6);

int main() {
    
    uint16_t msg;
    uint16_t reply;
    
    // Initialize with CS pin high
    cs = 1;
    
    // Set SPI for 16 data bits, mode 0
    spi.format(16, 0);
    
    // Construct message
    // Bit 0 (Start): Logic high (1)
    // Bit 1 (SGL/DIFF): 1 to select single mode
    // Bit 2 (ODD/SIGN): Select channel (0 or 1)
    // Bit 3 (MSBF): 0 for LSB
    // Bits 4-15: 0 (don't care)
    msg = 0b11;
    msg = ((msg << 1) + ADC_CHANNEL) << 13;
    
    while(1) {
        
        // Send out message and collect reply
        cs = 0;
        reply = spi.write(msg);
        cs = 1;
        
        // Get raw ADC value by shifting right once and 
        // masking out all but last 10 bits
        reply >>= 1;
        reply &= 0b0000001111111111;
        
        // Calculate voltage using assumed VREF voltage
        float voltage = (VREF * reply) / MAX_ADC;
        
        // Print out calculated voltage to the serial terminal
        serial.printf("%.2f V\r\n", voltage);
        
        wait(0.2);
    }
}
